nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))

vlrMedia = ((nota1+nota2+nota3)/3)

print("Resultado da média: ", vlrMedia)